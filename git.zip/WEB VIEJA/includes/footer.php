
<div style="margin-bottom: -50px; width: 100%; float: left;">
<center><img src="images/logos.png" usemap="#Map"><br>
<br>
<a href="http://knxis25.knx.org"><img style="border: 0px solid ; width: 903px; height: 119px;" alt="" src="images/knx.jpg"></a><br>
<br>
</center>
<map name="Map" id="Map">
<area shape="rect" coords="-8,1,63,55" href="http://www.knx.org" target="_blank">
<area shape="rect" coords="82,2,150,42" href="http://www.fibaro.com" target="_blank">
<area shape="rect" coords="163,1,240,44" href="http://eelectron.com" target="_blank">
<area shape="rect" coords="250,2,333,43" href="http://www.hdlautomation.com/" target="_blank">
<area shape="rect" coords="340,1,408,54" href="http://www.isde-ing.com/" target="_blank">
<area shape="rect" coords="419,4,471,44" href="http://www.globalcache.com/" target="_blank">
<area shape="rect" coords="498,4,570,39" href="http://www.iluflex.com.br/" target="_blank">
<area shape="rect" coords="590,4,649,45" href="http://www.eissound.com" target="_blank">
<area shape="rect" coords="673,4,754,57" href="http://www.youtube.com/watch?v=9sDu9RWUKJw" target="_blank">
</map>
</div>
<div style="width: 100%; float: left; margin-top: 75px;">
<div style="float: left; width: 50%; height: 150px;">
<p class="asd">DomoPy<br>
Instalaciones Dom�ticas e Inm�ticas<br>
Av. Sant�simo Sacramento 1047 - Tel.: 603-979<br>
<a href="mailto:comercial@domopy.com">comercial@domopy.com</a><br>
Asunci�n, Paraguay<?php echo date('Y') ?> . Todos los derechos
reservados.</p>
</div>
<div style="float: right; width: 20%; height: 75px;">
<p>Seguinos en:</p>
<ul class="social">
  <li><a href="https://www.facebook.com/pages/DomoPy/145841828771359" title="Seguinos en Facebook"><img src="images/logo_fb.png"></a></li>
  <li><a href="https://twitter.com/DomoPy" title="Seguinos en Twitter"><img src="images/logo_tw.png"></a></li>
  <li><a href="#" title="Seguinos en YouTube"><img src="images/logo_yt.png"></a></li>
</ul>
</div>
</div>

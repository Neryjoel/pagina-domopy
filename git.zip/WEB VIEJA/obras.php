<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
  <title>DomoPy - Instalaciones Dom�ticas e Imn�ticas</title>

  
  
  <link rel="index" title="Domopy - Domótica en Paraguay" href="http://www.domopy.com">

  
  <meta name="description" content="Domótica en Paraguay">

  
  <meta name="keywords" content="paraguay, paraguay domótica, domótica, domótica del paraguay, domo paraguay, domótica, domótica en paraguay, paraguay, domótica paraguay">

  
  <meta name="robots" content="index,follow">

  
  <link rel="canonical" href="http://www.domopy.com/">

  
  <link rel="stylesheet" type="text/css" href="css/reset.css">

  
  <link rel="stylesheet" type="text/css" href="css/960.css">

  
  <link rel="stylesheet" type="text/css" href="css/style.css">

  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
  
  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
  
  <script src="http://cdnjs.cloudflare.com/ajax/libs/cufon/1.09i/cufon-yui.js" type="text/javascript"></script>
  
  <script src="js/HelveticaNeueLT_Com_35_Th_250.font.js" type="text/javascript"></script>
  
  <script type="text/javascript">
	Cufon.replace('body', {hover: true});
	</script>
</head><body class="bg">
<div class="container_12">
<div class="grid_12" id="interna" style="width: 100%; position: relative;">
<div class="header"> <a href="/" class="logo"><img src="images/logo.gif"></a>
<ul class="nav">
  <li><a href="index.php">Inicio</a></li>
  <li><a href="empresa.php">La Empresa</a></li>
  <li><a href="servicios.php">Servicios</a></li>
  <li><a href="video.php">Multimedia</a></li>
  <li><a href="contacto.php">Contacto</a></li>
  <li><a href="obras.php" class="active">Fotos Obras</a></li>
</ul>
</div>
<div style="margin-top: 0px; height: 571px;" class="house"> <img style="width: 250px; height: 190px;" title="Obra Mangales" src="obras/foto1.jpg" alt="No se encuentra esta imagen"><img style="width: 338px; height: 190px;" alt="" src="obras/mangales.jpg"><img title="Obra Molas Lopez" style="width: 253px; height: 190px;" alt="" src="obras/Casa%20Molas%20Lopez.jpg"><img style="width: 253px; height: 190px;" alt="" src="obras/Casa%20Molas%20Lopez%201.jpg"><img style="width: 338px; height: 190px;" alt="" src="obras/cortes.jpg"><img style="width: 338px; height: 190px;" alt="" src="obras/cortes%201.jpg"><br>
<div style="margin-bottom: -50px; width: 100%; float: left;">
<center><img src="images/logos.png" usemap="#Map"></center>
<map name="Map" id="Map">
<area shape="rect" coords="-8,1,63,55" href="http://www" target="_blank">
<area shape="rect" coords="82,2,150,42" href="http://www" target="_blank">
<area shape="rect" coords="163,1,240,44" href="http://lutron.ripressroom.com" target="_blank">
<area shape="rect" coords="250,2,333,43" href="http://www.hdlspain.com/" target="_blank">
<area shape="rect" coords="340,1,408,54" href="http://www.iruleathome.com/" target="_blank">
<area shape="rect" coords="419,4,471,44" href="http://www.globalcache.com/" target="_blank">
<area shape="rect" coords="498,4,570,39" href="http://www.iluflex.com.br/" target="_blank">
<area shape="rect" coords="590,4,649,45" href="http://thinkflood.com/products/redeye/%20" target="_blank">
<area shape="rect" coords="673,4,754,57" href="" target="_blank">
</map>
</div>
<div style="width: 100%; float: left; margin-top: 75px;">
<div style="float: left; width: 50%; height: 150px;">
<p class="asd">DomoPy<br>
Instalaciones Dom�ticas e Inm�ticas<br>
Av. Sant�simo Sacramento 1047 - Tel.: 603-979<br>
<a href="mailto:comercial@domopy.com">comercial@domopy.com</a><br>
Asunci�n, Paraguay 2015. Todos los derechos reservados.</p>
</div>
<div style="float: right; width: 20%; height: 75px;">
<p>Seguinos en:</p>
<ul class="social">
  <li><a href="https://www.facebook.com/pages/DomoPy/145841828771359" title="Seguinos en Facebook"><img src="images/logo_fb.png"></a></li>
  <li><a href="https://twitter.com/DomoPy" title="Seguinos en Twitter"><img src="images/logo_tw.png"></a></li>
  <li><a href="#" title="Seguinos en YouTube"><img src="images/logo_yt.png"></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

</body></html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title>DomoPy - Instalaciones Dom&oacute;ticas e Imn&oacute;ticas</title>
<link rel='index' title='Domopy - Domótica en Paraguay' href='http://www.domopy.com' />
<meta name="description" content="Domótica en Paraguay" />
<meta name="keywords" content="paraguay, paraguay domótica, domótica, domótica del paraguay, domo paraguay, domótica, domótica en paraguay, paraguay, domótica paraguay" />
<meta name="robots" content="index,follow">
<link rel="canonical" href="http://www.domopy.com/" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/960.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/cufon/1.09i/cufon-yui.js" type="text/javascript"></script>
	<script src="js/HelveticaNeueLT_Com_35_Th_250.font.js" type="text/javascript"></script>
	<script type="text/javascript">
	Cufon.replace('body', {hover: true});
	</script>
</head>
<body class="bg">
	<div class="container_12">
		<div class="grid_12" id="interna" style="width:100%; position:relative">
			<?php include("includes/header.php") ?>
			<div>
<object width="940" height="705"><param name="movie" value="http://www.youtube.com/v/I_ojCGR_kE8?version=3&amp;hl=es_ES"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/I_ojCGR_kE8?version=3&amp;hl=es_ES" type="application/x-shockwave-flash" width="940" height="705" allowscriptaccess="always" allowfullscreen="true"></embed></object>
			</div>
			<?php include("includes/footer.php") ?>
		</div>
	</div>
</body>
</html>